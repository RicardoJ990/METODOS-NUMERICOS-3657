# IMPORTAMOS LAS BIBLIOTECAS QUE NECESITEMOS PARA REALIZAR NUESTRO EJERCICIO
import numpy as np
# INGRESO LA MATRIZ
A = np.array([[4., -1., 0., -1.],
              [-1., 4., -1., 0.],
              [0., -1., 4., -1.],
              [-1., 0., -1., 4.]])

B = np.array([[30.],
              [60.],
              [70.],
              [40.]])
# PROCEDIMIENTO

## DECLARAMOS VARIABLES TIPO COPIA DE A Y B
A2=np.copy(A)
B2=np.copy(B)
n = len(B)

# IMPRIMIMOS VALORES INICIALES EN PANTALLA
print(A)
print(B)
print("")
print("\x1b[1;34m"+"--------------------------------------------------------")

# MÉTODO DE ELIMINICIÓN GAUSSIANA SIN PIVOTEO
for k in range(0, n-1):
    for i in range(k+1, n):
        factor = A[i, k]/A[k, k]
        for j in range(k, n-1):
            A[i, j] -= factor*A[k, j]
        B[i] -= factor*B[k]
## DECLARAMOS VARIABLE x
x= np.zeros(n)

x[n-1]= B[n-1]/A[n-1, n-1]
for i in range(n-2, -1, -1):
    suma_j=0
    for j in range(i+1, n):
        suma_j += A[i,j] * x[j]
    x[i] = (B[i] - suma_j)/A[i,i]

# IMPRIMIMOS RESULTADO EN PANTALLA
print(A)
print(B)
print(x)
print(A2)
print(B2)

## NUESTRO RESIDUO ES | A.x-b |
print("\x1b[1;34m""El residuo es: " , np.linalg.norm(np.dot(A, x)-B))
print("\x1b[1;34m""La solución es: x = ",
      np.linalg.solve(A, B))
