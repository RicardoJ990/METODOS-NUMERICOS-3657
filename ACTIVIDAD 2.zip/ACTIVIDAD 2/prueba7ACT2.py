# IMPORTAMOS LAS BIBLIOTECAS QUE NECESITEMOS PARA REALIZAR NUESTRO EJERCICIO
import numpy as np

# INGRESO DE DATOS
A = np.array([[4, -1, 0, -1],
              [-1, 4, -1, 0],
              [0, -1, 4, -1],
              [-1, 0, -1, 4]])

B = np.array([[30],
              [60],
              [70],
              [40]])
# PROCEDIMIENTO
# NOS AYUDA AL PIVOTEO POR FILAS PUES UN VALOR CONSIDERADO CASI CERO PODRIA SER 1X10^-15
casi_cero = 1e-15  # Considerar como 0
# MÉTODO PARA EVITAR EL TRUNCAMIENTO EN OPERACIONES  truncamiento en operaciones
A = np.array(A, dtype=float)
# CONCATENACIÓN CON AYB
AB = np.concatenate((A, B), axis=1)
# PIVOTEO PARCIAL POR FILAS
tam = np.shape(AB)
n = tam[0]
m = tam[1]
# PARA CADA FILA EN MATRIZ AB
for i in range(0, n - 1, 1):
# COLUMNA DESDE DIAGONAL i HACIA ADELANTE
    columna = abs(AB[i:, i])
    donde_max = np.argmax(columna)
## donde_max NO ESTÁ EN LA DIAGONAL
    if (donde_max != 0):
# INTERCAMBIAMOS FILAS
        temporal = np.copy(AB[i, :])
        AB[i, :] = AB[donde_max + i, :]
        AB[donde_max + i, :] = temporal
# COPIAMOS AYB
AB1 = np.copy(AB)
#PROCESO DE ELIMINACIÓN GAUSSIANA CON PIVOTEO
for i in range(0, n - 1, 1):
    pivote = AB[i, i]
    adelante = i + 1
    for k in range(adelante, n, 1):
        factor = AB[k, i] / pivote
        AB[k, :] = AB[k, :] - AB[i, :] * factor
# REALIZAMOS SUSTITUCIÓN
ult_fila = n - 1
ult_columna = m - 1
# DECLARAMOS x
X = np.zeros(n, dtype=float)
for i in range(ult_fila, 0 - 1, -1):
    suma = 0
    for j in range(i + 1, ult_columna, 1):
        suma = suma + AB[i, j] * X[j]
    B1 = AB[i, ult_columna]
    X[i] = (B1 - suma) / AB[i, i]
X = np.transpose([X])
# SALIDA
print("\x1b[1;34m"+"Pivoteo Parcial Por Filas")
print(AB1)
print("\x1b[1;34m"+"La Solución es: ")
print(X)