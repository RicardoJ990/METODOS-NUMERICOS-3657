## IMPORTAMOS LIBRERÍAS NECESARIAS PARA REALIZAR EL EJERCICIO

import numpy as np
import math
import os
D
## PARA HACER MÁS INTERACTIVA LA PARTICIPACIÓN SE IMPLEMENTARÁ UN MENÚ PRINCIPAL

print("\x1b[1;34m"+"-------------------------------------------------------------------------------")
num = int(input("\x1b[1;34m"+"Por favor ingrese el número de cifras significativas --> "))

def funcion(x):
    return(x**3)+(2*x**2)+(10*x)-20
E = 0.5*10**(2-num)
i=0
x1 = int(input("\x1b[1;34m"+"Por favor ingrese el límite inferior --> "))
y1 = int(input("\x1b[1;34m"+"Por favor ingrese el límite inferior --> "))
print("\x1b[1;34m"+"-------------------------------------------------------------------------------")

## DATO EXTRA: "math.log()" --> DEVUELVE EL LOGARITMO NATURAL DE DIFERENTES NÚMEROS
w = int((math.log(y1-x1)-math.log(E))/math.log(2))
##LIMPIAR PANTALLA
os.system("clear")
 ## MENÚ PRINCIPAL
menu = """
    Bienvenido(a) 💾

1 - Resolución por método de Bisección.

2 - Resolución por método de Regula Falsi.

3 - Salir

Elige una opción: """

opcion = int(input(menu))

## MÉTODO DE LA BISECCIÓN
if opcion == 1:
    for i in range(w):
        z1 = (x1 + y1) / 2
        fun_a = funcion(x1)
        fun_b = funcion(y1)
        fun_c = funcion(z1)
        ## "i" SERÁ IGUAL AL NÚMERO DE ITERACIONES
        print(i + 1,"       ", x1, "        ", y1, "        ", z1, "        ", fun_a, "     ", fun_b, "     ", fun_c, "     ")
        if fun_c == 0:
            print("\x1b[1;34m"+"LA RAÍZ DE LA FUNCIÓN ES: ", z1)
            break
        elif fun_a * fun_c < 0:
            y1 = z1
        else:
            x1 = z1
## MÉTODO DE LA REGLA FALSA (Regula falsi)
elif opcion == 2:
    for i in range(w):
        fun_a = funcion(x1)
        fun_b = funcion(y1)
        ## QUE CAMBIA DE UN MÉTODO A OTRO?
        ### AQUÍ ESTÁ LA RESPUESTA
        z1 = ((x1 * fun_b) - (y1 * fun_a)) / (fun_b - fun_a)
        fun_c = funcion(z1)
        ## "i" SERÁ IGUAL AL NÚMERO DE ITERACIONES
        print(i + 1,"       ", x1, "        ", y1, "        ", z1, "        ", fun_a, "     ", fun_b, "     ", fun_c, "     ")
        if fun_c == 0:
            print("\x1b[1;34m"+"LA RAÍZ DE LA FUNCIÓN ES: ", z1)
            break
        elif fun_a * fun_c < 0:
            y1 = z1
        else:
            x1 = z1
## AL ESCOGER LA OPCIÓN 3 EN EL MENÚ PRINCIPAL SE DETENDRÁ TODO EL PROCESO
elif opcion == 3:
    quit()
## DE OTRO MODO SI SE DIGITA UNA OPCIÓN ERRÓNEA, SE LE NOTIFICARÁ AL USUARIO QUE HA DIGITADO INCORRECTAMENTE
else:
    print("\x1b[1;34m"+" 🛑 Ingrese una opción correcta por favor 🛑")