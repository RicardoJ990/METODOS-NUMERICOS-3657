## Invocamos las librerías a utilizar en nuestro ejercicio
import numpy as np
from random import randint
## Para hacer mas dinámica mi matriz 2x2, se generarán números enteros automáticamente
matriz= np.array([[randint(0,9),randint(0,9)],[randint(0,9),randint(0,9)]])
print("\x1b[1;34m"+"LA MATRIZ 2x2 GENERADA ES LA SIGUIENTE: ")
## Se imprime la matriz generada con numpy
print(matriz)
print("------------------------------")
## Gracias a la función linalg será posible calcular la inversa de nuestra matriz generada
print("\x1b[1;34m"+"SU INVERSA ES LA SIGUIENTE: ")
## Se imprime su inversa
print(np.linalg.inv(matriz))
