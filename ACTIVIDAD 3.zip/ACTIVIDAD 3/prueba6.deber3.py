## DECLARAMOS VARIABLES Y LIBRERÍAS A UTILIZAR EN NUESTRO EJERCICIO
import numpy as np
## DEFINIMOS UNA VARIABLE CONSTANTE PARA NUESTRO LIMITE ITERATIVO
LIMITE_ITER = 1000
## DECLARAMOS NUESTRA MATRIZ
A = np.array([[7., 1., -1., 2.],
          [1., 8., 0., -2.],
          [-1., -0., 4., -1.],
          [2., -2., -1., 6.]
          ])
## Y SU VECTOR B
b = np.array([3., -5., 4., -3.])
## MOSTRAMOS EL SISTEMA EN PANTALLA
print("\x1b[1;34m"+"EL SISTEMA ES:")
for i in range(A.shape[0]):
    fila = ["{0:3g}*x{1}".format(A[i, j], j + 1) for j in range(A.shape[1])]
    print("[{0}] = [{1:3g}]".format(" + ".join(fila), b[i]))

x = np.zeros_like(b)
## MÉTODO GAUSS SEIDEL
for it_count in range(1, LIMITE_ITER):
    x_new = np.zeros_like(x)
    print("ITERACIÓN {0}: {1}".format(it_count, x))
    for i in range(A.shape[0]):
        s1 = np.dot(A[i, :i], x_new[:i])
        s2 = np.dot(A[i, i + 1:], x[i + 1:])
        x_new[i] = (b[i] - s1 - s2) / A[i, i]
## DEFINIMOS LA PRECISIÓN DE 4 CIFRAS DECIMALES
    if np.allclose(x, x_new, rtol=1e-4):
        break
    x = x_new