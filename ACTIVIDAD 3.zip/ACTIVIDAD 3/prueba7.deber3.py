## DECLARAMOS VARIABLES Y LIBRERÍAS A UTILIZAR EN NUESTRO EJERCICIO
import numpy as np
import copy
import functools
import math
## PEDIMOS DATOS POR PANTALLA
a = input("\x1b[1;34m"+"INTRODUZCA EL NÚMERO DE LA VARIABLE INDEPENDIENTE X Y EL NÚMERO DE ECUACIONES: ")
## LOS GUARDAMOS RESPECTIVAMENTE EN ARREGLOS
mu, nu = [int(i) for i in a.split(" ")]
b = input("DIGITE LA PRESICIÓN DEL ERROR REQUERIDO (EN DECIMALES, EJ: 0.0001): ")
e = float(b)
## INICIALIZAMOS LA MATRIZ LDU
L, D, U = [], [], []
for p in range(nu):
    L.append([]), D.append([]), U.append([])
## INGRESAMOS LOS DATOS DEL SISTEMA POR TECLADO
    for q in range(mu):
        x_in = float(input("DIGITE EL COEFICIENTE EN LA FILA% d Y LA COLUMNA% d: " % (p + 1, q + 1)))
        if p < q:
            L[p].append(x_in), D[p].append(0), U[p].append(0)
        elif p == q:
            L[p].append(0), D[p].append(x_in), U[p].append(0)
        else:
            L[p].append(0), D[p].append(0), U[p].append(x_in)
L, D, U = np.array(L), np.array(D), np.array(U)
## ESTA ES NUESTRA VARIABLE INDEPENDIENTE X MATRIZ
X_Current = []
for q in range(mu):
    x_in = float(input("DIGITE EL VALOR INICIAL PARA X% d: " %q))
    X_Current.append(x_in)
## TRANSPONEMOS EL VECTOR DE FILA X A UN VECTOR DE COLUMNA PARA FACILITAR EL CÁLCULO DE LA MATRIZ SUBSIGUIENTE
X_Current = np.array(X_Current).T
## MATRIZ Y VARIABLE DEPENDIENTE
b_Const = []
for p in range(nu):
    y_in = float(input("DIGITE EL VALOR DE LA ECUACIÓN B/Y% d: " % (p + 1)))
    b_Const.append(y_in)
## REALIZAMOS LO MISMO DE ARRIBA PARA B
b_Const = np.array(b_Const).T
L_U = copy.deepcopy(L)
for p in range(nu):
    for q in range(mu):
## SUMA L Y U POR FILA Y SUMA LAS POSICIONES CORRESPONDIENTES
        L_U[p][q] = L[p][q] + U[p][q]
## AQUI ENCONTRAMOS LA INVERSA DE LA MATRIZ
G1 = np.dot(-np.linalg.inv(D), L_U)
d1 = np.dot(np.linalg.inv(D), b_Const)
## COPIAMOS SISTEMA
X_New = copy.deepcopy(X_Current)

## MÉTODO DE JACOBI
## INICIALIZAMOS ITERACIONES IGUAL A CERO
super = 0
while 1:
## AUXILIAR PARA LA PRESICIÓN DEL ERROR
    band = 0
    X_Current = X_New
    X_New = np.dot(G1, X_Current)
    for p in range(mu):
        X_New[p] = X_New[p] + d1[p]
        if math.fabs(X_New[p]-X_Current[p]) < e:
            band += 1
    super += 1
##  ESTABLECEMOS EL LÍMITE SUPERIOR DE ITERACIÓN EN 50 VECES
    if super > 50:
        print("\x1b[1;34m"+"LA ITERACIÓN NO CONVERGE")
        super = 0
        break
## MOSTRAMOS RESULTADOS EN PANTALLA
    if band == mu:
        print("\x1b[1;34m"+"LOS RESULTADOS SON: ")
        print(X_New)
        break
