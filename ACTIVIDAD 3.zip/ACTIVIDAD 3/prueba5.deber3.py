## DECLARAMOS VARIABLES Y LIBRERÍAS A UTILIZAR EN NUESTRO EJERCICIO
import math
MAX = 100
## INICIO DEL ALGORITMO
def Cholesky(matriz, n):
    infer = [[0 for x in range(n + 1)]
             for y in range(n + 1)]
## DESCOMPONEMOS LA MATRIZ EN SU DIAGONAL INFERIOR
    for i in range(n):
        for j in range(i + 1):
            sum1 = 0
## REALIZAMOS SUMATORIA DE LAS DIAGONALES
            if (j == i):
                for k in range(j):
    ## POW NOS AYUDA A ELEVAR UN NÚMERO PARA OPERARLO
                    sum1 += pow(infer[j][k], 2)
                infer[j][j] = int(math.sqrt(matriz[j][j] - sum1))
            else:
    # EVALUAMOS Y SEGUIDAMENTE USAMOS L(i, j)
                for k in range(j):
                    sum1 += (infer[i][k] * infer[j][k])
                if (infer[j][j] > 0):
                    infer[i][j] = int((matriz[i][j] - sum1) /
                                      infer[j][j])

## MOSTRAMOS EN PANTALLA LA DIAGONAL INFERIOR Y SU TRANSPUESTA
    print("\x1b[1;34m"+"DIAGONAL INFERIOR\t\tTRANSPUESTA")
    for i in range(n):
## DIAG. INFER.
        for j in range(n):
            print(infer[i][j], end="\t")
        print("\x1b[1;34m"+"", end="\t")
## TRANSPUESTA
        for j in range(n):
            print(infer[j][i], end="\t")
        print("")

## INGRESAMOS DATOS EN PANTALLA
n = 3
matriz = [[4, 6, 10],
          [6, 25, 19],
          [10, 19, 62]]
Cholesky(matriz, n)
