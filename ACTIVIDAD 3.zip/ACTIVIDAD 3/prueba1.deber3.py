## DECLARAMOS VARIABLES Y LIBRERÍAS A UTILIZAR EN NUESTRO EJERCICIO
from math import sqrt
import numpy as np
## DECLARAMOS SUS DIMENSIONES
fila = 2
col = 2
## DEFINIMOS MATRIZ CUADRADA
x = np.array([[2,4],[6,8]])
print("\x1b[1;34m"+"LA SIGUIENTE MATRIZ CUADRARA DE DIMENSIÓN 2 ESTÁ REPRESENTADA POR:")
print(x)
def frobenius(mat):
## AUXILIAR QUE ALMACENA LA SUMA DE LOS CUADRADOS DE LA MATRIZ OBTENIDA
    sum = 0
    for i in range(fila):
        for j in range(col):
            sum += pow(mat[i][j], 2)
## RETORNA LA RAÍZ CUADRADA DE LA SUMA DE CUADRADOS
    res = sqrt(sum)
## RETORNAMOS VALOR CON PRECISIÓN DE 4 CIFRAS DECIMALES
    return round(res, 4)
#3 MATRIZ OBTENIDA
mat = [[2, 4], [6, 8]]

print("\x1b[1;34m"+"LA NORMA DE FROBENIUS ES: ")
print(frobenius(mat))