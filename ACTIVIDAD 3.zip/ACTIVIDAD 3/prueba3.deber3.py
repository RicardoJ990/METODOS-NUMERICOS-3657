## DECLARAMOS VARIABLES Y LIBRERÍAS A UTILIZAR EN NUESTRO EJERCICIO
import numpy as np
## DEFINIMOS LAS DIMENSIONES DEL SISTEMA LINEAL
x = np.array([[6,0,0,0],[3,6,0,0],[4,-2,7,0],[5,-3,9,21]])
## DEFINIMOS LOS TÉRMINOS INDEPENDIENTES
y = np.array([12,-12,14,-2])
num_ec=np.size(y)
## LA SOLUCIÓN SE LEERA EN LA VARIABLE SOL
sol = np.zeros(num_ec)
## Aplicamos sustitución progresiva
for i in range(num_ec):
    sumj=0
    for j in range (i):
        sumj+=x[i,j]*sol[j]
    sol[i]=(y[i]-sumj)*1/x[i,i]
print("\x1b[1;34m"+"LAS SOLUCIONES SON: ")
print(sol)
